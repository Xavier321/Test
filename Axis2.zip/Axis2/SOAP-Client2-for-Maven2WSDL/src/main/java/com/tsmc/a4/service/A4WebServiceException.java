
/**
 * A4WebServiceException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.0  Built on : May 17, 2011 (04:19:43 IST)
 */

package com.tsmc.a4.service;

public class A4WebServiceException extends java.lang.Exception{

    private static final long serialVersionUID = 1442939833738L;
    
    private com.tsmc.a4.service.AuthorizationServiceServiceStub.Fault1 faultMessage;

    
        public A4WebServiceException() {
            super("A4WebServiceException");
        }

        public A4WebServiceException(java.lang.String s) {
           super(s);
        }

        public A4WebServiceException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public A4WebServiceException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(com.tsmc.a4.service.AuthorizationServiceServiceStub.Fault1 msg){
       faultMessage = msg;
    }
    
    public com.tsmc.a4.service.AuthorizationServiceServiceStub.Fault1 getFaultMessage(){
       return faultMessage;
    }
}
    