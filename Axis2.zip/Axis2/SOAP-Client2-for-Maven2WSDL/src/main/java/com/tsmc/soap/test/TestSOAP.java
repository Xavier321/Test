package com.tsmc.soap.test;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;

import com.tsmc.a4.service.A4WebServiceException;
import com.tsmc.a4.service.AuthorizationServiceServiceStub;
import com.tsmc.a4.service.AuthorizationServiceServiceStub.DoAuthorizationService;
import com.tsmc.a4.service.AuthorizationServiceServiceStub.DoAuthorizationServiceResponse;

public class TestSOAP {
	
	public static void main(String[] args) {

		//new TestSOAP().callWebService();
		new TestSOAP().callSOAP("http://localhost:8181/a4Secure/services/authorizationService");
		System.out.println("1123");

	}
	
	public void callSOAP(String url){
		
		try {
			AuthorizationServiceServiceStub stub = new AuthorizationServiceServiceStub(url);
			HttpTransportProperties.Authenticator auth = new HttpTransportProperties.Authenticator();
			auth.setUsername("SHLINZZI");
			auth.setPassword("karaf");
			stub._getServiceClient().getOptions().setProperty(HTTPConstants.AUTHENTICATE, auth);
			
			
			DoAuthorizationService doAuthorizationService = new DoAuthorizationService();
			doAuthorizationService.setXmlMessage("hello~~~");
			
			DoAuthorizationServiceResponse doAuthorizationServiceResponse;
			
			try {
				doAuthorizationServiceResponse = stub.doAuthorizationService(doAuthorizationService);
				System.out.println(doAuthorizationServiceResponse.getDoAuthorizationServiceReturn());
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (A4WebServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (AxisFault e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}

}
