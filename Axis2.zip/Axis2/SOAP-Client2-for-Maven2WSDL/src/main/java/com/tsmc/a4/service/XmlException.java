
/**
 * XmlException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.0  Built on : May 17, 2011 (04:19:43 IST)
 */

package com.tsmc.a4.service;

public class XmlException extends java.lang.Exception{

    private static final long serialVersionUID = 1442939833698L;
    
    private com.tsmc.a4.service.AuthorizationServiceServiceStub.Fault faultMessage;

    
        public XmlException() {
            super("XmlException");
        }

        public XmlException(java.lang.String s) {
           super(s);
        }

        public XmlException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public XmlException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(com.tsmc.a4.service.AuthorizationServiceServiceStub.Fault msg){
       faultMessage = msg;
    }
    
    public com.tsmc.a4.service.AuthorizationServiceServiceStub.Fault getFaultMessage(){
       return faultMessage;
    }
}
    