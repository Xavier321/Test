package com.tsmc.a4.secure.osgi.ws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthenticationImpl implements Authentication{
	private final static Logger logger = LoggerFactory.getLogger(AuthenticationImpl.class);
	
	public String doService(String xmlMessage) {
		
		String result = "AuthenticationImpl doService";
		return result;
	}

	public String doAuthenticationService(String xmlMessage) {

		String result = "AuthenticationImpl doAuthenticationService";
		return result;
	}

}
