package com.tsmc.a4.secure.osgi.ws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthorizationImpl implements Authorization{
	private final static Logger logger = LoggerFactory.getLogger(AuthorizationImpl.class);

	public String doService(String xmlMessage) {

		String result = "AuthorizationImpl doService";
		return result;
	}

	public String doAuthorizationService(String xmlMessage) {
		
		String result = "AuthorizationImpl doAuthorizationService";
		return result;
	}

}
