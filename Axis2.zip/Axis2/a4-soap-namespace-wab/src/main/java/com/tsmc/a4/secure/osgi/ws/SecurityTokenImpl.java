package com.tsmc.a4.secure.osgi.ws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SecurityTokenImpl implements SecurityToken{
	private final static Logger logger = LoggerFactory.getLogger(AuthenticationImpl.class);

	public String doService(String xmlMessage) {
		
		String result = "SecurityTokenImpl doService";
		return result;
	}

	public String doSecurityTokenService(String xmlMessage) {
		
		String result = "SecurityTokenImpl doSecurityTokenService";
		return result;
	}

}
