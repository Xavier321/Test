package com.tsmc.a4.secure.osgi.ws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DataAuthorizationImpl implements DataAuthorization{
	private final static Logger logger = LoggerFactory.getLogger(DataAuthorizationImpl.class);

	public String doService(String xmlMessage) {
		
		String result = "DataAuthorizationImpl doService";
		return result;
	}

	public String doDataAuthorizationService(String xmlMessage) {
		
		String result = "DataAuthorizationImpl doDataAuthorizationService";
		return result;
	}

}
