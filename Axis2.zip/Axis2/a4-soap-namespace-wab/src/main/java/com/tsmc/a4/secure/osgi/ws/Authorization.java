package com.tsmc.a4.secure.osgi.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.WebResult;

import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

//@WebService
//@WebService(name = "AuthorizationService", portName = "AuthorizationService", serviceName = "authorizationService", targetNamespace = "http://a08avidet12:8181/a4Secure/services/authorizationService?wsdl")
@WebService(name = "AuthorizationService", portName = "AuthorizationService", serviceName = "authorizationService", targetNamespace = "http://ws.osgi.secure.a4.tsmc.com")
public interface Authorization {
	
	//@WebResult(name="return",targetNamespace="http://a08avidet12:8181/a4Secure/services/authorizationService?wsdl")  
	@WebMethod(action = "doServiceRequest", operationName = "doServiceRequest", exclude = false)
	//public String doService(final String xmlMessage);
	//public String doService( @WebParam(name = "arg0", targetNamespace="http://ws.osgi.secure.a4.tsmc.com") final String xmlMessage);
    @RequestWrapper(localName = "doService", targetNamespace = "http://ws.osgi.secure.a4.tsmc.com")
    @ResponseWrapper(localName = "doServiceResponse", targetNamespace = "http://ws.osgi.secure.a4.tsmc.com")
	public String doService( @WebParam(targetNamespace="http://ws.osgi.secure.a4.tsmc.com") final String xmlMessage);
	
	//@WebResult(name="return",targetNamespace="http://a08avidet12:8181/a4Secure/services/authorizationService?wsdl")  
	@WebMethod(action = "doAuthorizationServiceRequest", operationName = "doAuthorizationServiceRequest", exclude = false)
	//public String doAuthorizationService(final String xmlMessage);
	//public String doAuthorizationService( @WebParam(name = "arg0", targetNamespace="http://ws.osgi.secure.a4.tsmc.com") final String xmlMessage);
    @RequestWrapper(localName = "doAuthorizationService", targetNamespace = "http://ws.osgi.secure.a4.tsmc.com")
    @ResponseWrapper(localName = "doAuthorizationServiceResponse", targetNamespace = "http://ws.osgi.secure.a4.tsmc.com")
	public String doAuthorizationService( @WebParam(targetNamespace="http://ws.osgi.secure.a4.tsmc.com") final String xmlMessage);

}
