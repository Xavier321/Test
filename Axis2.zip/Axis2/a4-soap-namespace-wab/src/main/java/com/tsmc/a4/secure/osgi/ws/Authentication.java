package com.tsmc.a4.secure.osgi.ws;

import javax.jws.WebParam;
import javax.jws.WebService;

//@WebService
@WebService(targetNamespace = "http://ws.osgi.secure.a4.tsmc.com")
public interface Authentication {
	
	
	//public String doService(final String xmlMessage);
	public String doService( @WebParam(targetNamespace="http://ws.osgi.secure.a4.tsmc.com") final String xmlMessage);

	//public String doAuthenticationService(final String xmlMessage);
	public String doAuthenticationService( @WebParam(targetNamespace="http://ws.osgi.secure.a4.tsmc.com") final String xmlMessage);

}
