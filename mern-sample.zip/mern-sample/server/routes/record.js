const express = require("express");
const ObjectId = require('mongodb').ObjectID;

// recordRoutes is an instance of the express router.
// We use it to define our routes.
// The router will be added as a middleware and will take control of requests starting with path /record.
const recordRoutes = express.Router();

//This will help us connect to the database
const dbo = require("../db/conn");

// This section will help you get a list of all the records.
recordRoutes.route("/record").get(function (req, res) {
  let db_connect = dbo.getDb("employees");
  db_connect
    .collection("records")
    .find({})
    .toArray(function (err, result) {
      if (err) throw err;
      res.json(result);
    });
});

// This section will help you create a new record.
recordRoutes.route("/record/add").post(function (req, res) {
  let db_connect = dbo.getDb("employees");
  let myobj = {
    person_name: req.body.person_name,
    person_position: req.body.person_position,
    person_level: req.body.person_level,
  };
  db_connect.collection("records").insertOne(myobj, function (err, res) {
    if (err) throw err;
  });
});

// This section will help you update a record by id.
//recordRoutes.route("/update/:id/:person_name/:person_position/:person_level").post(function (req, res) {
recordRoutes.route("/update/:id").post(function (req, res) {
  let db_connect = dbo.getDb("employees");
  let myquery = { _id: ObjectId(req.params.id) };
  console.log("req.params.id:" + "\"" + req.params.id + "\"");
  //console.log("req.params.id:" + person_name + person_position + person_level);
  let newvalues = {
    $set: {
      person_name: req.body.person_name,
      person_position: req.body.person_position,
      person_level: req.body.person_level,
    },
  };
  db_connect
    .collection("records")
    .updateOne(myquery, newvalues, function (err, res) {
    //.updateOne({ _id: ObjectId("612bab82cc48e837f0961d09")}, newvalues, function (err, res) {
      if (err) throw err;
      console.log("1 document updated");
    });
});

// This section will help you delete a record
recordRoutes.route("/:id").delete((req, res) => {
  let db_connect = dbo.getDb("employees");
  let myquery = { _id: ObjectId(req.params.id) };
  console.log("req.params.id" + req.params.id);
  db_connect.collection("records").deleteOne(myquery, function (err, obj) {
    if (err) throw err;
    console.log("1 document deleted");
  });
});

recordRoutes.route("/delete/:id").get((req, res) => {
  let db_connect = dbo.getDb("employees");
  var myquery = { _id: req.params.id };
  let y = ObjectId('612babfacc48e837f0961d0a');
  console.log("req.params.id: " + req.params.id);
  try {
    //db_connect.collection("records").deleteOne( '{ _id : ObjectId("612babfacc48e837f0961d0a") }' );
    db_connect.collection("records").deleteOne( { _id : y } );

  } catch (e) {
    //print(e);
    console.log(e);
  }

});

// This section will help you update a record by id.
recordRoutes.route("/updateMe/:id").get(function (req, res) {
  let db_connect = dbo.getDb("employees");
  let myquery = { _id: '612d073aeb73c09e2b389285' };
  let newvalues = {
    $set: {
      A: '999',
      B: '888',
    },
  };
  db_connect
    .collection("records")
    .updateOne(myquery, newvalues, function (err, res) {
      if (err) throw err;
      console.log("1 document updated");
    });
});

module.exports = recordRoutes;
